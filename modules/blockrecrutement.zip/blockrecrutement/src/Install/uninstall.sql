ALTER TABLE _DB_PREFIX_cms_lang DROP COLUMN `date_upd_page`;
